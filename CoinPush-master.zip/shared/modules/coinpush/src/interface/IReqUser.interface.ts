export interface IReqUser {
	id?: string;
}