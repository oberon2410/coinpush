"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IUser.interface.js.map