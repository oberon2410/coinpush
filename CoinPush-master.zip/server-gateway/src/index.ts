import { app } from './app';

app.init().catch(console.error);
