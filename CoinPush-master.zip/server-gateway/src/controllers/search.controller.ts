import * as request from 'request-promise';
import { config } from 'coinpush/src/util/util-config';

export const searchController = {

	async byText(reqUser, params?): Promise<any> {
		const results = await Promise.all([
			request({
				uri: config.server.user.apiUrl + '/user',
				headers: {_id: reqUser.id},
				qs: params,
				json: true
			})
		]);

		return {
			users: results[0]
		};
	}
};