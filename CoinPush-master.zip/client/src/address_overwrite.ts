
const options = {
    "app": {
        "host": "http",
        "ip": "192.168.178.11",
        "port": 4000
    }
}

export default {
    "app": {
        // "secure": false,
        // "host": "http",
        // "ip": "192.168.178.11",
        // "port": 4000,
        // "ws": "ws"
    }
};